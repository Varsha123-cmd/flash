package com.assignment2;

public interface Piano {
default void play() {
	System.out.println("Piano default method");
	
}
}
