package com.assignment3;
@FunctionalInterface
public interface WordCount {
public int count(String str); 
	}

